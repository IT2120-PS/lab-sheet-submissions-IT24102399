setwd("C:\\Users\\it24102399\\Desktop\\IT24102399")
getwd()

delivery_times <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")
head(delivery_times)

breaks <- seq(20,70,length.out=10)
hist(delivery_times$Delivery_Time_.minutes., 
     breaks = breaks, 
     right = TRUE, 
     col="lightblue",
     main = "Histogram of Delivery Times", 
     xlab = "Delivery Times", 
     ylab = "Frequency",
     border= "black" )

freq <- hist(delivery_times$Delivery_Time_.minutes., 
                  breaks = breaks, 
                  right = TRUE, 
                  plot = FALSE)

cum_freq <- cumsum(freq$counts)

plot(breaks[-1],
     cum_freq,
     type='o',
     pch=16,
     col="red",
     main="Cumulative Frequency Polygon (Ogive)", 
     xlab="Delivery Times", 
     ylab="Cumulative Frequency")

